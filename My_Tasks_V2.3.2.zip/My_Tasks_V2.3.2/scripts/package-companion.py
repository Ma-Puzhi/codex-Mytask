"""Package the exact companion sources for installation and Site downloads."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
destination = root / "public/downloads/MyTasks_Chat_Bridge.zip"
destination.parent.mkdir(parents=True, exist_ok=True)
with ZipFile(destination, "w") as archive:
    for name in ("manifest.json", "background.js", "shared.js", "site.js", "chat.js", "README.md"):
        info = ZipInfo("MyTasks_Chat_Bridge/" + name, date_time=(2026, 10, 8, 0, 0, 0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, (root / "companion" / name).read_bytes())
print(destination)
